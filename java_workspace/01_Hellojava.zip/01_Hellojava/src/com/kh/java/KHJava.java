package com.kh.java;

public class KHJava {

	public void welcome() {
		System.out.println("어서 오십시오!");
	}
}
