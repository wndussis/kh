package com.kh.java.other;

public class OtherJava {
	

	public void callMe() {
		//sysout - ctrl + space
		System.out.println("call me call me!!!");
		
		
		
		printTest p = new PrintTest();
		p.test1();
		p.test2();
		
		public void test2() {
			
			System.out.println("abc" + "def");
			
			
			System.out.println()
			       
		}
		
		
	
	
	}
	
	public void test1() {
		System.out.println("안녕");// 출력후 개행
		System.out.print("하");//출력
		System.out.print("하");//출력
		System.out.print("하");//출력
		
		
        //윈도우 디렉토리 구분자는 역슬래시를 사용한다
		System.out.println("C:\\dev\\eclipse\\eclipse.exe");

		
		/**
		 * 문자열 더하기 연산
		 * 1. 문자열+문자열 => 문자열
		 * 2. 문자열+숫자 => 문자열
		 * 3. 숫자 + 숫자 => 숫자
		 * 
		 * 
		 */
		
		public void test3()  {
			System.out.println("가나다" + "라마바사");//"가나다라마바사"
			System.out.println("abc" + 123); // "abc123"
			System.out.println("123" + 4); // "1234"
			System.out.println(12 + 34); //46
			
			
			System.out.println(12 + "34" + 56);// "123456"
			System.out.println(12 + 34 + "56");// 46 + "56" = "4656"
			System.out.println("12" + 3 * 7);// "12"+ 21 = "1221"
		}
}
