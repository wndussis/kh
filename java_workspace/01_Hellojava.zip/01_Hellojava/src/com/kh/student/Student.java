package com.kh.student;
/**
 * 실행클래스
 * -메인메소드를 가진 클래스
 */

public class Student {
	
	public static void main(String[] args)  {
		
		student stdt = new student();
		stdt.introduce();
		
public class student {
	
	public void introduce() {
		System.out.println("안녕하세요 , 3학년 2반 홍길동입니다.");
	}
}
		
		
	    
	}

}
